# pacman
a simple pacman written in javascript

**TODO**
* catch keypress events
* add a board
* add enemies
* add score table
* add levels

